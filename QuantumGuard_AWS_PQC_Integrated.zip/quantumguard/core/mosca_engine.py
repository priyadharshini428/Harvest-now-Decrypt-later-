"""
Mosca's Inequality & Quantum Risk Assessment Engine (Q-Score Algorithm).
Implements mathematical modeling of "Harvest Now, Decrypt Later" (HNDL).
"""
import re
from typing import Tuple, Dict, Any
from database.models import (
    CryptoAsset,
    VulnerabilityRecord,
    RiskTier,
    ExposureLevel
)

class MoscaEngine:
    def __init__(
        self,
        crqc_year: int = 2033,
        current_year: int = 2026,
        default_migration_years: float = 3.0
    ):
        self.crqc_year = crqc_year
        self.current_year = current_year
        self.default_migration_years = default_migration_years
        self.z_horizon = max(1.0, float(self.crqc_year - self.current_year))

    def infer_shelf_life(self, name: str, location: str, purpose: str) -> float:
        """
        Infers data confidentiality shelf-life (X) in years based on context heuristics.
        """
        combined = f"{name} {location} {purpose}".lower()
        
        # Long-term sensitive (20 - 30 years)
        if any(k in combined for k in ["medical", "health", "phi", "patient", "biometric", "genomic", "national_security", "classified"]):
            return 30.0
            
        # Financial / High PII (10 - 20 years)
        if any(k in combined for k in ["banking", "payment", "pci", "credit", "ssn", "identity", "tax", "payroll", "legal"]):
            return 15.0
            
        # Corporate Confidential / Credentials (5 - 10 years)
        if any(k in combined for k in ["auth", "token", "jwt", "session_secret", "master_key", "ca_cert", "root_ca", "api_key", "password"]):
            return 8.0
            
        # Standard web & application traffic (3 - 5 years)
        if any(k in combined for k in ["tls", "https", "ssl", "nginx", "apache", "ingress", "gateway", "service"]):
            return 5.0
            
        # Ephemeral / Dev (0.5 - 2 years)
        if any(k in combined for k in ["test", "demo", "mock", "temp", "scratch", "cache"]):
            return 1.0
            
        return 7.0

    def evaluate_primitive_vulnerability(self, algorithm: str, key_size: int = None) -> Tuple[float, bool, bool, str]:
        """
        Returns (base_vulnerability_score, is_shor_vulnerable, is_grover_vulnerable, description)
        """
        algo = algorithm.upper().strip()
        
        # 1. NIST Post-Quantum Standards (Safe)
        pqc_standards = ["ML-KEM", "KYBER", "ML-DSA", "DILITHIUM", "SLH-DSA", "SPHINCS+", "FALCON", "LMS", "XMSS"]
        if any(pqc in algo for pqc in pqc_standards):
            return 0.0, False, False, "NIST Post-Quantum Cryptography Standard (Quantum-Resistant)"
            
        # 2. Hybrid Post-Quantum (Safe / Compliant)
        if "HYBRID" in algo or ("X25519" in algo and "KYBER" in algo) or "PQC" in algo:
            return 2.0, False, False, "Composite Classical-Quantum Hybrid Primitive"
            
        # 3. Asymmetric Primitives (Shor's Algorithm - Complete Break)
        if "RSA" in algo:
            if key_size and key_size < 2048:
                return 100.0, True, False, f"Legacy RSA-{key_size} (Shor's polynomial time break + classical weakness)"
            elif key_size and key_size >= 4096:
                return 90.0, True, False, f"RSA-{key_size} (Shor's algorithm breaks in polynomial time O(n^3))"
            else:
                return 95.0, True, False, "RSA-2048 (Shor's algorithm breaks in polynomial time O(n^3))"
                
        if any(ec in algo for ec in ["ECDSA", "ECDH", "EC_", "CURVE25519", "X25519", "ED25519", "SECP256", "PRIME256"]):
            return 95.0, True, False, "Elliptic Curve Cryptography (Broken by Shor's discrete logarithm attack)"
            
        if any(dh in algo for dh in ["DIFFIE-HELLMAN", "DH", "DHE", "DSA"]):
            return 98.0, True, False, "Discrete Logarithm / Diffie-Hellman (Broken by Shor's algorithm)"

        # 4. Classical Broken Legacy
        if any(legacy in algo for legacy in ["DES", "3DES", "RC4", "MD5", "SHA1", "SHA-1"]):
            return 100.0, True, True, "Deprecated Legacy Algorithm (Classically broken & quantum vulnerable)"

        # 5. Symmetric Ciphers (Grover's Algorithm quadratic speedup)
        if "AES" in algo or "CHACHA" in algo:
            if key_size == 128 or "128" in algo:
                return 48.0, False, True, "AES-128 (Grover's algorithm reduces effective security from 128 to 64 bits)"
            elif key_size == 192 or "192" in algo:
                return 20.0, False, True, "AES-192 (Grover's algorithm reduces effective security to 96 bits)"
            elif key_size == 256 or "256" in algo:
                return 5.0, False, False, "AES-256 (Grover-resistant: retains 128 bits of post-quantum security)"
            else:
                return 35.0, False, True, "Symmetric cipher with indeterminate key length"

        # 6. Hashes
        if any(h in algo for h in ["SHA256", "SHA-256", "SHA3-256"]):
            return 10.0, False, False, "Collision resistant; minimal quantum threat"
        if any(h in algo for h in ["SHA384", "SHA-384", "SHA512", "SHA-512"]):
            return 2.0, False, False, "Grover-resistant secure hash"

        return 50.0, False, False, "Unclassified cryptographic primitive"

    def assess_asset(self, asset: CryptoAsset) -> Tuple[VulnerabilityRecord, str]:
        """
        Runs Mosca's inequality and calculates dynamic Q-Score for a single asset.
        """
        # Ensure shelf life is set
        if not asset.data_shelf_life_years or asset.data_shelf_life_years <= 0:
            asset.data_shelf_life_years = self.infer_shelf_life(asset.name, asset.location, asset.purpose)

        X = float(asset.data_shelf_life_years)
        Y = float(self.default_migration_years)
        Z = self.z_horizon

        # Mosca Gap: Delta = X + Y - Z
        mosca_gap = round((X + Y) - Z, 2)
        
        # Time to compromise:
        # If an attacker intercepts today (2026), quantum decrypt becomes possible at year 2026 + Z.
        time_to_compromise = round(Z, 1)

        # Base vulnerability score V
        base_v, shor_vuln, grover_vuln, reason = self.evaluate_primitive_vulnerability(
            asset.algorithm, asset.key_size
        )

        # Exposure weight W_exp
        exposure_map = {
            ExposureLevel.PUBLIC_INTERNET.value: 1.4,
            ExposureLevel.INTERNAL_NETWORK.value: 1.1,
            ExposureLevel.AT_REST_STORAGE.value: 1.0,
            ExposureLevel.LOCAL_DEV.value: 0.6
        }
        w_exp = exposure_map.get(asset.exposure_level, 1.0)

        # Agility factor A (0.1 = rigid hardcode, 0.7 = config / agile)
        agility = 0.2
        if asset.asset_type in ["CONFIG_FILE", "TLS_ENDPOINT"]:
            agility = 0.6
        elif "modular" in str(asset.raw_metadata).lower():
            agility = 0.8

        # Q-Score Computation
        if base_v == 0.0:
            q_score = 0.0
            severity = RiskTier.QUANTUM_SAFE.value
            urgency_tier = "Compliant (NIST PQC)"
        else:
            # Dynamic Mosca Urgency Multiplier
            mosca_multiplier = 1.0
            if mosca_gap > 0:
                # In HNDL Danger Zone: accelerate penalty proportionally to the exposure gap
                mosca_multiplier = 1.0 + (mosca_gap / max(1.0, Z))
            else:
                # Safety margin exists, slight discount
                mosca_multiplier = max(0.5, 1.0 - (abs(mosca_gap) / (2.0 * Z)))

            raw_q = base_v * mosca_multiplier * (w_exp / 1.4) * (1.1 - agility)
            q_score = round(min(100.0, max(0.0, raw_q)), 1)

            # Assign Severity & Urgency
            if q_score >= 80.0 or (mosca_gap > 0 and shor_vuln and w_exp >= 1.0):
                severity = RiskTier.CRITICAL.value
                urgency_tier = "Immediate (HNDL Danger Zone)"
            elif q_score >= 60.0:
                severity = RiskTier.HIGH.value
                urgency_tier = "Phase 1 (Within 12 Months)"
            elif q_score >= 35.0:
                severity = RiskTier.MEDIUM.value
                urgency_tier = "Phase 2 (Within 24 Months)"
            else:
                severity = RiskTier.LOW.value
                urgency_tier = "Phase 3 (Routine Modernization)"

        explanation = (
            f"{reason}. Mosca Parameters: Data Shelf-Life X={X} yrs, Migration Time Y={Y} yrs, "
            f"Quantum Horizon Z={Z} yrs (CRQC Year {self.crqc_year}). "
        )
        if mosca_gap > 0:
            explanation += f"CRITICAL: X + Y > Z (Deficit of {mosca_gap} years). Data is actively exposed to Harvest Now, Decrypt Later."
        else:
            explanation += f"SAFE BUFFER: X + Y <= Z (Buffer of {abs(mosca_gap)} years before estimated quantum threshold)."

        vuln_record = VulnerabilityRecord(
            asset_id=asset.id,
            scan_id=asset.scan_id,
            q_score=q_score,
            severity=severity,
            shor_vulnerable=shor_vuln,
            grover_vulnerable=grover_vuln,
            mosca_gap_years=mosca_gap,
            time_to_compromise_years=time_to_compromise,
            urgency_tier=urgency_tier,
            explanation=explanation
        )

        return vuln_record, explanation
