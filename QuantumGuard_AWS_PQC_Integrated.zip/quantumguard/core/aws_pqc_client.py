"""AWS post-quantum cryptography integration for QuantumGuard."""
import boto3
from botocore.exceptions import ClientError, BotoCoreError


class AWSPQClient:
    def __init__(self, region_name="us-west-2"):
        self.region_name = region_name
        self.kms_client = boto3.client("kms", region_name=region_name)
        self.pca_client = boto3.client("acm-pca", region_name=region_name)

    def create_mldsa_signing_key(self, alias_name="alias/QuantumGuard-ML-DSA"):
        """Request an ML-DSA-65 signing key in AWS KMS."""
        try:
            response = self.kms_client.create_key(
                KeySpec="ML_DSA_65",
                KeyUsage="SIGN_VERIFY",
                Description="QuantumGuard PQC-ready ML-DSA-65 signing key",
                Tags=[{"TagKey": "Project", "TagValue": "QuantumGuard"}],
            )
            key_id = response["KeyMetadata"]["KeyId"]
            try:
                self.kms_client.create_alias(AliasName=alias_name, TargetKeyId=key_id)
            except (ClientError, BotoCoreError):
                # Do not hide the created key if alias creation fails.
                return {"status": "partial", "key_id": key_id, "alias": alias_name,
                        "message": "Key created, but alias creation failed. Check whether the alias already exists and your IAM permissions."}
            return {"status": "success", "key_id": key_id, "alias": alias_name}
        except (ClientError, BotoCoreError) as exc:
            return {"status": "error", "message": str(exc)}
        except Exception as exc:
            return {"status": "error", "message": str(exc)}

    def check_cloud_tls_readiness(self):
        """Return demo data only; replace with live AWS inventory for production."""
        return [
            {"resource": "arn:aws:elasticloadbalancing:us-west-2:111122223333:loadbalancer/app/prod-lb/50dc",
             "type": "ALB", "tls_version": "TLS 1.3", "key_exchange": "X25519MLKEM768",
             "pqc_ready": True, "source": "demo"},
            {"resource": "arn:aws:apigateway:us-west-2:111122223333:/restapis/legacy-api",
             "type": "ApiGateway", "tls_version": "TLS 1.2", "key_exchange": "ECDHE-RSA-AES128",
             "pqc_ready": False, "source": "demo"},
        ]
