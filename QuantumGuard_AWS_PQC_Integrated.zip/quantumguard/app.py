"""
QuantumGuard Web Application & REST API Server (Flask).
Enterprise-grade Post-Quantum Cryptography Scanner and CBOM Manager.
"""
import os
import json
import threading
from typing import Dict, Any, Optional
from flask import Flask, request, jsonify, render_template, send_from_directory, make_response
from flask_cors import CORS

from database import db
from scanners.orchestrator import ScanOrchestrator
from cbom.cyclonedx import CycloneDXExporter
from core.aws_pqc_client import AWSPQClient

# Initialize database schema
db.init_db()

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
STATIC_DIR = os.path.join(BASE_DIR, "static")
TEMPLATES_DIR = os.path.join(BASE_DIR, "templates")

app = Flask(
    __name__,
    static_folder=STATIC_DIR,
    template_folder=TEMPLATES_DIR
)
CORS(app)

orchestrator = ScanOrchestrator()
aws_client = None

def get_aws_client():
    global aws_client
    if aws_client is None:
        aws_client = AWSPQClient(region_name=os.environ.get("AWS_REGION", "us-west-2"))
    return aws_client

# Background worker
def execute_scan_worker(scan_id: int, target_type: str, target_path: str):
    orchestrator.run_scan(scan_id, target_type, target_path)

# --- Routes ---

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/api/health")
def health():
    return jsonify({"status": "ok", "version": "2.4.0", "engine": "Mosca-QScore-v2"})

@app.route("/api/dashboard")
def get_dashboard():
    scan_id_str = request.args.get("scan_id")
    scan_id = int(scan_id_str) if scan_id_str and scan_id_str.isdigit() else None
    summary = db.get_dashboard_summary(scan_id)
    return jsonify(summary)

@app.route("/api/scans")
def list_scans():
    scans = db.list_scans()
    return jsonify({"scans": scans})

@app.route("/api/scans/<int:scan_id>")
def get_scan_details(scan_id: int):
    scan = db.get_scan(scan_id)
    if not scan:
        return jsonify({"error": "Scan not found"}), 404
    findings = db.get_scan_findings(scan_id)
    return jsonify({"scan": scan, "findings": findings})

@app.route("/api/scans/<int:scan_id>/logs")
def get_scan_logs(scan_id: int):
    logs = db.get_scan_logs(scan_id)
    return jsonify({"logs": logs})

@app.route("/api/scan", methods=["POST"])
def trigger_scan():
    data = request.get_json(silent=True) or {}
    name = data.get("name", "Corporate Crypto Audit")
    target_type = data.get("target_type", "local_directory")
    target_path = data.get("target_path", "").strip()

    # Defaults if empty
    if not target_path:
        if target_type in ["local_directory", "combined"]:
            target_path = os.path.join(BASE_DIR, "sample_targets")
        elif target_type == "network_tls":
            target_path = "google.com:443"

    scan_id = db.create_scan(
        name=name,
        target_type=target_type,
        target_path=target_path
    )

    # Launch background thread
    t = threading.Thread(
        target=execute_scan_worker,
        args=(scan_id, target_type, target_path),
        daemon=True
    )
    t.start()

    return jsonify({
        "status": "QUEUED",
        "scan_id": scan_id,
        "name": name,
        "target_path": target_path
    })

@app.route("/api/scans/<int:scan_id>/cbom")
def export_cbom(scan_id: int):
    scan = db.get_scan(scan_id)
    if not scan:
        return jsonify({"error": "Scan not found"}), 404
    findings = db.get_scan_findings(scan_id)
    cbom_json = CycloneDXExporter.export_cbom(scan, findings)
    
    response = make_response(json.dumps(cbom_json, indent=2))
    response.headers["Content-Type"] = "application/json"
    response.headers["Content-Disposition"] = f"attachment; filename=cbom-scan-{scan_id}.json"
    return response

@app.route("/api/settings", methods=["GET", "POST"])
def manage_settings():
    if request.method == "POST":
        data = request.get_json(silent=True) or {}
        if "crqc_horizon_year" in data:
            db.update_setting("crqc_horizon_year", str(data["crqc_horizon_year"]))
        if "default_migration_time_years" in data:
            db.update_setting("default_migration_time_years", str(data["default_migration_time_years"]))
        if "default_shelf_life_years" in data:
            db.update_setting("default_shelf_life_years", str(data["default_shelf_life_years"]))
        return jsonify({"status": "SUCCESS", "settings": db.get_settings()})
    return jsonify(db.get_settings())

@app.route("/api/aws/status", methods=["GET"])
def get_aws_status():
    try:
        return jsonify(get_aws_client().check_cloud_tls_readiness())
    except Exception as exc:
        return jsonify({"error": str(exc), "message": "AWS status demo data could not be loaded."}), 503

@app.route("/api/aws/create-mldsa", methods=["POST"])
def create_mldsa():
    try:
        result = get_aws_client().create_mldsa_signing_key()
        code = 200 if result.get("status") in ("success", "partial") else 400
        return jsonify(result), code
    except Exception as exc:
        return jsonify({"status": "error", "message": str(exc)}), 500

@app.route("/api/sample-path")
def get_sample_path():
    return jsonify({"path": os.path.join(BASE_DIR, "sample_targets")})

if __name__ == "__main__":
    app.run(host="127.0.0.1", port=8000, debug=False)
