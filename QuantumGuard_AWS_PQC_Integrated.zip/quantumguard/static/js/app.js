/**
 * QuantumGuard Frontend Application Controller.
 * Manages real-time scanning, Mosca risk scatter charts, CBOM filtering, and code diffs.
 */

let currentScanId = null;
let currentFindings = [];
let currentSummary = null;
let scatterChartInstance = null;
let doughnutChartInstance = null;
let pollInterval = null;

// On Page Load
document.addEventListener("DOMContentLoaded", () => {
    initApp();
    setupEventListeners();
});

async function initApp() {
    await loadSettings();
    await loadScansList();
}

function setupEventListeners() {
    document.getElementById("scanSelector").addEventListener("change", (e) => {
        if (e.target.value) {
            loadScan(parseInt(e.target.value));
        }
    });

    document.getElementById("searchInput").addEventListener("input", filterAndRenderTable);
    document.getElementById("filterRisk").addEventListener("change", filterAndRenderTable);
    document.getElementById("filterType").addEventListener("change", filterAndRenderTable);
}

// --- API Calls ---

async function loadScansList() {
    try {
        const res = await fetch("/api/scans");
        const data = await res.json();
        const selector = document.getElementById("scanSelector");
        selector.innerHTML = "";

        if (!data.scans || data.scans.length === 0) {
            const opt = document.createElement("option");
            opt.value = "";
            opt.textContent = "No audits yet - Launch a scan";
            selector.appendChild(opt);
            // Auto open scan modal or load sample
            openNewScanModal();
            return;
        }

        data.scans.forEach((s) => {
            const opt = document.createElement("option");
            opt.value = s.id;
            opt.textContent = `#${s.id} - ${s.name} (${s.target_type}) - ${s.status}`;
            selector.appendChild(opt);
        });

        // Load the latest scan
        currentScanId = data.scans[0].id;
        selector.value = currentScanId;
        await loadScan(currentScanId);
    } catch (err) {
        console.error("Error loading scans list:", err);
    }
}

async function loadScan(scanId) {
    currentScanId = scanId;
    try {
        const res = await fetch(`/api/scans/${scanId}`);
        const data = await res.json();
        currentFindings = data.findings || [];

        // Also fetch dashboard aggregated summary
        const sumRes = await fetch(`/api/dashboard?scan_id=${scanId}`);
        currentSummary = await sumRes.json();

        updateKPIs(currentSummary);
        renderCharts(currentFindings, currentSummary);
        filterAndRenderTable();

        // Select the highest risk finding for the diff studio by default
        if (currentFindings.length > 0) {
            selectFindingForDiff(currentFindings[0]);
        }
    } catch (err) {
        console.error("Error loading scan details:", err);
    }
}

async function loadSettings() {
    try {
        const res = await fetch("/api/settings");
        const data = await res.json();
        if (data.crqc_horizon_year) {
            document.getElementById("settingHorizon").value = data.crqc_horizon_year;
        }
        if (data.default_migration_time_years) {
            document.getElementById("settingMigration").value = data.default_migration_time_years;
        }
        if (data.default_shelf_life_years) {
            document.getElementById("settingShelf").value = data.default_shelf_life_years;
        }
    } catch (err) {
        console.error("Error loading settings:", err);
    }
}

// --- UI Updates ---

function updateKPIs(summary) {
    if (!summary) return;

    const readiness = summary.readiness_pct !== undefined ? summary.readiness_pct : 0;
    const critical = summary.hndl_critical !== undefined ? summary.hndl_critical : 0;
    const total = summary.total_assets !== undefined ? summary.total_assets : 0;

    document.getElementById("kpiReadiness").textContent = `${readiness}%`;
    document.getElementById("kpiCritical").textContent = critical;
    document.getElementById("kpiTotal").textContent = total;

    // Runway: (CRQC Year - 2026) - Migration Time
    const horizonYear = summary.scan_meta?.raw_summary?.crqc_horizon_year || 2033;
    const migYears = summary.scan_meta?.raw_summary?.migration_years || 3.0;
    const runway = Math.max(0, (horizonYear - 2026) - migYears);
    document.getElementById("kpiRunway").textContent = `${runway.toFixed(1)} yrs`;

    // Threat banner
    document.getElementById("bannerThreatCount").textContent = `${critical} Assets at Immediate HNDL Risk`;

    // Stats
    const shorCount = currentFindings.filter(f => f.shor_vulnerable).length;
    const groverCount = currentFindings.filter(f => f.grover_vulnerable).length;
    const safeCount = currentFindings.filter(f => f.severity === "QUANTUM_SAFE").length;

    document.getElementById("statShor").textContent = shorCount;
    document.getElementById("statGrover").textContent = groverCount;
    document.getElementById("statSafe").textContent = safeCount;
}

// --- Chart Rendering ---

function renderCharts(findings, summary) {
    renderScatterChart(findings);
    renderDoughnutChart(summary?.tier_breakdown || {});
}

function renderScatterChart(findings) {
    const ctx = document.getElementById("moscaScatterChart").getContext("2d");
    if (scatterChartInstance) {
        scatterChartInstance.destroy();
    }

    const scatterData = findings.map(f => {
        let color = "#ef4444"; // red
        if (f.severity === "HIGH") color = "#f59e0b"; // amber
        else if (f.severity === "MEDIUM") color = "#3b82f6"; // blue
        else if (f.severity === "LOW") color = "#94a3b8"; // slate
        else if (f.severity === "QUANTUM_SAFE") color = "#10b981"; // emerald

        return {
            x: f.data_shelf_life_years,
            y: f.q_score,
            assetName: f.asset_name,
            algorithm: f.algorithm,
            moscaGap: f.mosca_gap_years,
            severity: f.severity,
            color: color
        };
    });

    scatterChartInstance = new Chart(ctx, {
        type: "scatter",
        data: {
            datasets: [{
                label: "Cryptographic Assets",
                data: scatterData,
                backgroundColor: scatterData.map(d => d.color),
                borderColor: scatterData.map(d => d.color),
                pointRadius: 6,
                pointHoverRadius: 9
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                x: {
                    title: {
                        display: true,
                        text: "Data Confidentiality Shelf-Life X (Years)",
                        color: "#94a3b8",
                        font: { size: 11 }
                    },
                    grid: { color: "rgba(255, 255, 255, 0.05)" },
                    ticks: { color: "#94a3b8" }
                },
                y: {
                    min: 0,
                    max: 105,
                    title: {
                        display: true,
                        text: "Quantum Risk Q-Score (0 - 100)",
                        color: "#94a3b8",
                        font: { size: 11 }
                    },
                    grid: { color: "rgba(255, 255, 255, 0.05)" },
                    ticks: { color: "#94a3b8" }
                }
            },
            plugins: {
                legend: { display: false },
                tooltip: {
                    backgroundColor: "#0f172a",
                    borderColor: "#334155",
                    borderWidth: 1,
                    titleColor: "#38bdf8",
                    bodyColor: "#f1f5f9",
                    callbacks: {
                        label: function(context) {
                            const p = context.raw;
                            return [
                                `Asset: ${p.assetName}`,
                                `Algorithm: ${p.algorithm}`,
                                `Shelf-Life (X): ${p.x} yrs`,
                                `Q-Score: ${p.y}`,
                                `Mosca Gap (Δ): ${p.moscaGap} yrs`,
                                `Tier: ${p.severity}`
                            ];
                        }
                    }
                }
            }
        }
    });
}

function renderDoughnutChart(breakdown) {
    const ctx = document.getElementById("severityDoughnutChart").getContext("2d");
    if (doughnutChartInstance) {
        doughnutChartInstance.destroy();
    }

    const labels = ["Critical", "High", "Medium", "Low", "Quantum Safe"];
    const counts = [
        breakdown.CRITICAL || 0,
        breakdown.HIGH || 0,
        breakdown.MEDIUM || 0,
        breakdown.LOW || 0,
        breakdown.QUANTUM_SAFE || 0
    ];

    doughnutChartInstance = new Chart(ctx, {
        type: "doughnut",
        data: {
            labels: labels,
            datasets: [{
                data: counts,
                backgroundColor: ["#ef4444", "#f59e0b", "#3b82f6", "#64748b", "#10b981"],
                borderColor: "#090d16",
                borderWidth: 2
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: "right",
                    labels: { color: "#94a3b8", font: { size: 10 }, boxWidth: 10 }
                }
            },
            cutout: "65%"
        }
    });
}

// --- CBOM Table & Filter ---

function filterAndRenderTable() {
    const searchVal = document.getElementById("searchInput").value.toLowerCase().trim();
    const riskVal = document.getElementById("filterRisk").value;
    const typeVal = document.getElementById("filterType").value;

    const filtered = currentFindings.filter(f => {
        const matchesSearch = !searchVal || 
            f.asset_name.toLowerCase().includes(searchVal) ||
            f.algorithm.toLowerCase().includes(searchVal) ||
            f.location.toLowerCase().includes(searchVal);

        const matchesRisk = riskVal === "ALL" || f.severity === riskVal;
        const matchesType = typeVal === "ALL" || f.asset_type === typeVal;

        return matchesSearch && matchesRisk && matchesType;
    });

    renderTableBody(filtered);
    document.getElementById("tableCountBadge").textContent = `${filtered.length} Items`;
}

function renderTableBody(findings) {
    const tbody = document.getElementById("findingsTableBody");
    tbody.innerHTML = "";

    if (findings.length === 0) {
        tbody.innerHTML = `
            <tr>
                <td colspan="9" class="py-8 text-center text-slate-500">
                    No cryptographic primitives matched your filter criteria.
                </td>
            </tr>
        `;
        return;
    }

    findings.forEach((f) => {
        const tr = document.createElement("tr");
        tr.className = "hover:bg-slate-900/80 transition cursor-pointer group";
        tr.onclick = (e) => {
            // If click wasn't on button, select for diff
            if (!e.target.closest("button")) {
                selectFindingForDiff(f);
            }
        };

        const badgeClass = getSeverityBadgeClass(f.severity);
        const gapColor = f.mosca_gap_years > 0 ? "text-red-400 font-bold" : "text-emerald-400";

        tr.innerHTML = `
            <td class="py-3 px-4">
                <div class="font-semibold text-slate-200 group-hover:text-cyan-400 transition">${escapeHtml(f.asset_name)}</div>
                <div class="text-[10px] text-slate-500 font-mono truncate max-w-xs">${escapeHtml(f.location)}${f.line_number ? ':' + f.line_number : ''}</div>
            </td>
            <td class="py-3 px-4">
                <span class="text-[10px] px-2 py-0.5 rounded bg-slate-800 text-slate-300 font-mono border border-slate-700">${f.asset_type}</span>
            </td>
            <td class="py-3 px-4">
                <span class="font-bold text-slate-200">${escapeHtml(f.algorithm)}</span>
                ${f.key_size ? `<span class="text-[10px] text-slate-400 font-mono ml-1">(${f.key_size}-bit)</span>` : ''}
            </td>
            <td class="py-3 px-4 text-[11px] text-slate-300">
                ${f.exposure_level}
            </td>
            <td class="py-3 px-4 font-mono text-amber-300 text-center">
                ${f.data_shelf_life_years} yrs
            </td>
            <td class="py-3 px-4 font-mono ${gapColor} text-center">
                ${f.mosca_gap_years > 0 ? '+' : ''}${f.mosca_gap_years} yrs
            </td>
            <td class="py-3 px-4 font-mono font-bold text-purple-400 text-center">
                ${f.q_score}
            </td>
            <td class="py-3 px-4 text-center">
                <span class="text-[10px] font-bold px-2.5 py-0.5 rounded-full ${badgeClass}">${f.severity}</span>
            </td>
            <td class="py-3 px-4 text-center">
                <button onclick='openInspectModal(${JSON.stringify(f).replace(/'/g, "&#39;")})' 
                        class="p-1.5 rounded bg-slate-800 hover:bg-cyan-950 hover:text-cyan-400 text-slate-400 transition" title="Inspect Deep Metadata">
                    <i class="fa-solid fa-eye"></i>
                </button>
            </td>
        `;
        tbody.appendChild(tr);
    });
}

function getSeverityBadgeClass(sev) {
    switch (sev) {
        case "CRITICAL": return "badge-critical";
        case "HIGH": return "badge-high";
        case "MEDIUM": return "badge-medium";
        case "LOW": return "badge-low";
        case "QUANTUM_SAFE": return "badge-safe";
        default: return "bg-slate-800 text-slate-300";
    }
}

// --- Migration Diff Studio ---

function selectFindingForDiff(f) {
    document.getElementById("diffTitle").textContent = f.code_diff_title || `Migrate ${f.algorithm} to Post-Quantum Standard`;
    document.getElementById("diffSubtitle").textContent = `Remediation path for ${f.asset_name} (${f.location})`;
    document.getElementById("diffStandardBadge").textContent = f.standard_reference || "NIST FIPS 203 / 204";
    
    document.getElementById("diffOldPrimitive").textContent = f.algorithm;
    document.getElementById("diffOldCode").textContent = f.current_code_snippet || "# Current implementation";
    
    document.getElementById("diffNewPrimitive").textContent = f.nist_standard_replacement || "ML-KEM-768";
    document.getElementById("diffNewCode").textContent = f.migrated_code_snippet || "# Post-quantum migration code";

    document.getElementById("diffRecipeText").textContent = f.configuration_recipe || "Implement NIST standardized post-quantum cryptographic primitives.";

    // Scroll slightly if user clicked row
    const diffSection = document.getElementById("remediationStudio");
    diffSection.classList.add("ring-1", "ring-cyan-500/50");
    setTimeout(() => diffSection.classList.remove("ring-1", "ring-cyan-500/50"), 1200);
}

// --- Modals & Scan Handling ---

function openNewScanModal() {
    document.getElementById("newScanModal").classList.remove("hidden");
    updateTargetPlaceholder();
}

function closeNewScanModal() {
    document.getElementById("newScanModal").classList.add("hidden");
    if (pollInterval) clearInterval(pollInterval);
}

function updateTargetPlaceholder() {
    const selected = document.querySelector('input[name="scanType"]:checked').value;
    const input = document.getElementById("scanPathInput");
    const label = document.getElementById("targetPathLabel");
    const help = document.getElementById("targetHelpText");

    if (selected === "local_directory") {
        label.textContent = "Target Directory Path:";
        input.placeholder = "C:\\path\\to\\project\\or\\certs";
        help.textContent = "Point to any codebase folder, system certificate directory, or web project.";
    } else if (selected === "network_tls") {
        label.textContent = "Target Network Host & Port:";
        input.placeholder = "google.com:443 (or cloudflare.com:443)";
        help.textContent = "Initiates a real socket TLS handshake and inspects negotiated cipher suites and certificates.";
    } else {
        label.textContent = "Combined Target (Directory / Host):";
        input.placeholder = "C:\\path\\to\\code OR hostname:443";
        help.textContent = "Executes both local file parsing and live network TLS probes.";
    }
}

async function loadSampleTarget() {
    try {
        const res = await fetch("/api/sample-path");
        const data = await res.json();
        document.getElementById("scanPathInput").value = data.path;
    } catch (err) {
        console.error("Error loading sample path:", err);
    }
}

async function handleStartScan(e) {
    e.preventDefault();
    const name = document.getElementById("scanNameInput").value;
    const type = document.querySelector('input[name="scanType"]:checked').value;
    const path = document.getElementById("scanPathInput").value;

    const btn = document.getElementById("btnSubmitScan");
    btn.disabled = true;
    btn.innerHTML = `<i class="fa-solid fa-spinner fa-spin"></i><span>Scanning...</span>`;

    const consoleWrapper = document.getElementById("scanConsoleWrapper");
    consoleWrapper.classList.remove("hidden");
    const consoleBox = document.getElementById("scanConsole");
    consoleBox.innerHTML = '<div class="text-cyan-400">> Initializing QuantumGuard discovery engine...</div>';

    try {
        const res = await fetch("/api/scan", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ name: name, target_type: type, target_path: path })
        });
        const data = await res.json();
        const scanId = data.scan_id;

        // Poll logs
        pollInterval = setInterval(async () => {
            const logRes = await fetch(`/api/scans/${scanId}/logs`);
            const logData = await logRes.json();
            consoleBox.innerHTML = "";
            (logData.logs || []).forEach(l => {
                const color = l.level === "SUCCESS" ? "text-emerald-400" :
                              l.level === "ERROR" ? "text-red-400" :
                              l.level === "WARNING" ? "text-amber-400" : "text-slate-300";
                consoleBox.innerHTML += `<div class="${color}">[${l.level}] ${escapeHtml(l.message)}</div>`;
            });
            consoleBox.scrollTop = consoleBox.scrollHeight;

            // Check scan status
            const statusRes = await fetch(`/api/scans/${scanId}`);
            const statusData = await statusRes.json();
            if (statusData.scan && statusData.scan.status !== "RUNNING" && statusData.scan.status !== "PENDING") {
                clearInterval(pollInterval);
                btn.disabled = false;
                btn.innerHTML = `<i class="fa-solid fa-check"></i><span>Completed</span>`;
                setTimeout(async () => {
                    closeNewScanModal();
                    await loadScansList();
                }, 1000);
            }
        }, 800);

    } catch (err) {
        console.error("Scan launch error:", err);
        btn.disabled = false;
        btn.innerHTML = `Start Real Discovery`;
    }
}

// --- Inspect Modal ---

function openInspectModal(f) {
    document.getElementById("inspectModal").classList.remove("hidden");
    document.getElementById("inspectTitle").textContent = f.asset_name;
    document.getElementById("inspectLocation").textContent = `${f.location}${f.line_number ? ' (Line ' + f.line_number + ')' : ''}`;
    document.getElementById("inspectAlgo").textContent = f.algorithm;
    document.getElementById("inspectKeySize").textContent = f.key_size ? `${f.key_size} bits` : "N/A";
    document.getElementById("inspectExposure").textContent = f.exposure_level;
    document.getElementById("inspectShelf").textContent = `${f.data_shelf_life_years} years`;
    document.getElementById("inspectMoscaGap").textContent = `${f.mosca_gap_years > 0 ? '+' : ''}${f.mosca_gap_years} years`;
    document.getElementById("inspectQScore").textContent = `${f.q_score} / 100`;
    document.getElementById("inspectExplanation").textContent = f.explanation;
    document.getElementById("inspectSnippet").textContent = f.code_snippet || JSON.stringify(f.raw_metadata, null, 2);
}

function closeInspectModal() {
    document.getElementById("inspectModal").classList.add("hidden");
}

// --- Settings Modal ---

function openSettingsModal() {
    document.getElementById("settingsModal").classList.remove("hidden");
}

function closeSettingsModal() {
    document.getElementById("settingsModal").classList.add("hidden");
}

async function handleSaveSettings(e) {
    e.preventDefault();
    const horizon = parseInt(document.getElementById("settingHorizon").value);
    const mig = parseFloat(document.getElementById("settingMigration").value);
    const shelf = parseFloat(document.getElementById("settingShelf").value);

    try {
        await fetch("/api/settings", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
                crqc_horizon_year: horizon,
                default_migration_time_years: mig,
                default_shelf_life_years: shelf
            })
        });
        closeSettingsModal();
        if (currentScanId) {
            await loadScan(currentScanId);
        }
    } catch (err) {
        console.error("Save settings error:", err);
    }
}

// --- CBOM Export ---

function exportCurrentCBOM() {
    if (!currentScanId) {
        alert("Please run or select a scan first.");
        return;
    }
    window.location.href = `/api/scans/${currentScanId}/cbom`;
}

// Helper
function escapeHtml(str) {
    if (!str) return "";
    return String(str).replace(/[&<>"']/g, function(m) {
        return {
            '&': '&amp;',
            '<': '&lt;',
            '>': '&gt;',
            '"': '&quot;',
            "'": '&#039;'
        }[m];
    });
}
