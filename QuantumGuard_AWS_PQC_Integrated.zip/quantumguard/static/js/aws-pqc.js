// AWS PQC panel; kept separate so the existing QuantumGuard UI logic is unchanged.
document.addEventListener("DOMContentLoaded", () => {
  const refresh = document.getElementById("awsRefreshBtn");
  const create = document.getElementById("awsCreateKeyBtn");
  if (refresh) refresh.addEventListener("click", loadAwsPqcStatus);
  if (create) create.addEventListener("click", createAwsMldsaKey);
  loadAwsPqcStatus();
});

async function loadAwsPqcStatus() {
  const body = document.getElementById("awsPqcTable");
  const message = document.getElementById("awsPqcMessage");
  if (!body || !message) return;
  message.textContent = "Loading status…";
  try {
    const response = await fetch("/api/aws/status");
    const data = await response.json();
    if (!response.ok || !Array.isArray(data)) throw new Error(data.message || data.error || "Could not load status");
    body.replaceChildren();
    data.forEach(item => {
      const tr = document.createElement("tr");
      const values = [item.resource, item.type, item.tls_version, item.key_exchange,
        `${item.pqc_ready ? "PQ-ready (reported)" : "Needs review"} · ${item.source || "unknown"}`];
      values.forEach((value, i) => {
        const td = document.createElement("td");
        td.className = "py-3 pr-4 " + (i === 0 ? "font-mono text-xs break-all text-slate-300" : "text-slate-200");
        td.textContent = value == null ? "" : String(value);
        tr.appendChild(td);
      });
      body.appendChild(tr);
    });
    message.textContent = "Status loaded. The included endpoint records are demo data, not live AWS discovery.";
  } catch (error) {
    message.textContent = "AWS status unavailable: " + error.message;
  }
}

async function createAwsMldsaKey() {
  const button = document.getElementById("awsCreateKeyBtn");
  const message = document.getElementById("awsPqcMessage");
  if (!button || !message) return;
  if (!confirm("This sends a real AWS KMS create-key request and may incur charges. Continue?")) return;
  button.disabled = true;
  message.textContent = "Requesting AWS KMS ML-DSA key…";
  try {
    const response = await fetch("/api/aws/create-mldsa", {method: "POST", headers: {"Content-Type": "application/json"}, body: "{}"});
    const result = await response.json();
    if (!response.ok || result.status === "error") throw new Error(result.message || "Key creation failed");
    message.textContent = result.status === "success"
      ? `Key created: ${result.key_id} · Alias: ${result.alias}`
      : `Partial result: ${result.message || JSON.stringify(result)}`;
  } catch (error) {
    message.textContent = "ML-DSA key request failed: " + error.message + ". Verify AWS region, SDK support, IAM permissions, and credentials.";
  } finally {
    button.disabled = false;
  }
}
