# QuantumGuard: Post-Quantum Discovery, CBOM & Migration Platform

> **An enterprise platform to discover where quantum-vulnerable cryptography is in use across an organization, evaluate "Harvest Now, Decrypt Later" (HNDL) exposure using Mosca's Theorem, and generate actionable NIST PQC migration roadmaps.**

---

## 1. Problem Statement: "Harvest Now, Decrypt Later" (HNDL)
Encrypted data intercepted and archived by adversaries today can be decrypted in the future once a **Cryptographically Relevant Quantum Computer (CRQC)** emerges. Current public-key cryptography relies on mathematical problems breakable in polynomial time by **Shor's Algorithm**:
* **RSA**: Integer factorization ($O((\log N)^3)$)
* **ECDSA / ECDH**: Discrete logarithm problem over elliptic curve groups
* **Diffie-Hellman / DSA**: Finite-field discrete logarithm

Furthermore, **Grover's Algorithm** accelerates brute-force search quadratically, halving symmetric cipher effective key lengths (e.g., AES-128 drops to 64-bit security). High-longevity confidential data (health records, financial systems, government communications) is in immediate peril.

---

## 2. Core Novelty & Real Algorithms

### A. Mathematical Risk Engine: Mosca's Theorem ($X + Y > Z$)
QuantumGuard evaluates risk using Dr. Michele Mosca's inequality:
$$\Delta = (X + Y) - Z$$
* **$X$ (Confidentiality Shelf-Life)**: Years the data must remain confidential (e.g., 30 yrs for HIPAA/genomics, 15 yrs for banking, 5 yrs for session data).
* **$Y$ (Migration Time)**: Years required to migrate systems to post-quantum cryptography.
* **$Z$ (Quantum Horizon)**: Time until CRQC arrival ($2033 - 2026 = 7.0$ years).

If $\mathbf{X + Y > Z}$ ($\Delta > 0$), the organization is in the **HNDL Danger Zone**: data transmitted today will be decrypted while still confidential.

### B. Dynamic Quantum Urgency Score ($Q_{\text{score}} \in [0, 100]$)
$$Q_{\text{score}} = \text{clamp}\left(0, 100, V_{\text{primitive}} \times \left(1 + \frac{\max(0, \Delta)}{Z}\right) \times \frac{W_{\text{exp}}}{1.4} \times (1.1 - A_{\text{agility}})\right)$$
* **$V_{\text{primitive}}$**: 100 for broken classical, 95 for Shor-breakable RSA/ECC, 48 for AES-128, 5 for AES-256, 0 for NIST PQC.
* **$W_{\text{exp}}$**: Exposure weight (Public Internet = 1.4, Internal RPC = 1.1, Storage = 1.0, Local = 0.6).
* **$A_{\text{agility}}$**: Implementation agility factor.

### C. Tri-Vector Native Discovery Engine (No Mocks)
1. **Live Network / TLS Scanner**: Executes real socket-level handshakes with servers (e.g., `google.com:443`, internal gateways) to extract negotiated cipher suites, curves, and X.509 certificates.
2. **X.509 Certificate & ASN.1 Parser**: Uses Python's native `cryptography` library to parse `.pem`, `.crt`, `.der`, `.key`, and SSH keys.
3. **Multi-Language AST Source Code Scanner**: Scans Python AST trees and regex patterns across JavaScript/TypeScript, Go, Java, and C/C++.
4. **DevOps & Web Server Config Parser**: Scans Nginx, Apache, OpenSSL, and Dockerfile crypto configurations.

### D. NIST FIPS 203/204/205 Alignment & Diff Studio
Maps legacy primitives to finalized NIST post-quantum standards:
* **ML-KEM-768 / ML-KEM-1024** (FIPS 203) for Key Encapsulation (replacing RSA/ECDH)
* **ML-DSA-65 / ML-DSA-87** (FIPS 204) for Digital Signatures (replacing RSA-PSS/ECDSA)
* **SLH-DSA** (FIPS 205) for Stateless Hash-based Signatures
* **Hybrid Key Exchanges**: `X25519 + ML-KEM-768` (draft-ietf-tls-hybrid-design) for backward compatibility

### E. Standard CycloneDX 1.6 CBOM Export
Exports full Cryptographic Bill of Materials in official CycloneDX 1.6 JSON format for enterprise security pipeline integration.

---

## 3. Persistent SQLite Database Architecture
All audits, assets, risk scores, and migration plans are stored locally in `data/quantumguard.db`:
* `scans`: Historical audit sessions and metrics.
* `assets`: Discovered cryptographic assets and metadata.
* `vulnerabilities`: Computed Mosca gaps, Shor/Grover flags, and Q-Scores.
* `migration_recommendations`: Actionable code diffs and configuration recipes.
* `scan_logs`: Timestamped discovery event logs.
* `settings`: Configurable Mosca parameters ($Z, Y, X$).

---

## 4. Quickstart & Running the Application

### 1. Install Dependencies
```bash
pip install -r requirements.txt
```

### 2. Start Web Server
```bash
python app.py
```
Open your browser at: **`http://127.0.0.1:8000`**

### 3. Run Your First Scan
1. Click **"Launch New Scan"**.
2. Click **"Use Sample Targets"** to immediately scan the built-in testbed containing real RSA, ECC, and AES assets.
3. Or enter a live TLS host (e.g. `google.com:443` or `cloudflare.com:443`) to run real network handshakes.
4. Watch the live discovery stream in the terminal.
5. Explore the interactive **Mosca Risk Matrix**, inspect CBOM assets, view side-by-side migration diffs, and download the CycloneDX 1.6 CBOM.
